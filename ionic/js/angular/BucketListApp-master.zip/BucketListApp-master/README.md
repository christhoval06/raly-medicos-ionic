BucketListApp
=============
The App we are going to build is a Bucket List app. Here a user can register and login. 
Then s/he can create a few bucket list items.
